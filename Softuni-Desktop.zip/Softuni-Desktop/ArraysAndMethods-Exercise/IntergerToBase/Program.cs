﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntergerToBase
{
    class Program
    {
        static void Main(string[] args)
        {
            long n = long.Parse(Console.ReadLine());

            int toBase = int.Parse(Console.ReadLine());

            Console.WriteLine(IntegerToBase(n, toBase));
        }
        static string IntegerToBase(long number, int toBase)
        {
            string result = String.Empty;
            while(number>0)
            {
                long remainder = number % toBase;
                result = remainder + result;
                number /= toBase;
            }
            return result;
        }
    }
}
