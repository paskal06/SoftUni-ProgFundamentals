﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Notifications
{
    class Program
    {
        static string ShowSuccess(string op,string msg)
        {
            Console.WriteLine("Successfully executed {0}.",op);
            Console.WriteLine("==============================");
            Console.WriteLine("Message: {0}.", msg);
            return "";
        }
        static string ShowError(string op, int code)
        {
            string reason = "";
            if (code > 0)
            {
                reason = "Invalid Client Data";
            }
            else
            {
                reason = "Internal System Failure";
            }

            Console.WriteLine("Error: Failed to execute {0}.", op);
            Console.WriteLine("==============================");
            Console.WriteLine("Error Code: {0}.", code);
            Console.WriteLine("Reason: {0}.",reason);
            return "";
        }
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 1; i <= n; i++)
            {
                string result = Console.ReadLine();
                if (result == "success")
                {
                    ShowSuccess(Console.ReadLine(), Console.ReadLine());
                }else if(result == "error")
                {
                    ShowError(Console.ReadLine(), int.Parse(Console.ReadLine()));
                }
            }
        }
    }
}
