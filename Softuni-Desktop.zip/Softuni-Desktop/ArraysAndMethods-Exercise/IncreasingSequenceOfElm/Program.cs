﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IncreasingSequenceOfElm
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] numbers = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();
            
            for (int i = 0; i < numbers.Length; i++)
            {
                if (i != 0)
                {
                    if (numbers[i] != numbers[i - 1])
                    {
                        
                        Console.WriteLine("No");
                        return;
                    }
                }
            }
            
                Console.WriteLine("Yes");
            
            
        }
    }
}
