﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArraysAndMethods_Exercise
{
    class Program
    {
        static void Hello(string name)
        {
            Console.WriteLine("Hello, {0}!", name);
            
        }
        static void Main(string[] args)
        {
            string name = Console.ReadLine();
            Hello(name);
        }
    }
}
