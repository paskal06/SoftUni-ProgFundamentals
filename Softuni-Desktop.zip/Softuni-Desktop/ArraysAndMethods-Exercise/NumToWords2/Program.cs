﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumToWords2
{
    class Program
    {
        static string teenIt(int ones)
        {
            string result = "";
            if (ones == 0) { result = "ten"; }
            if (ones == 1) { result = "eleven"; }
            if (ones == 2) { result = "twelve"; }
            if (ones == 3) { result = "thirteen"; }
            if (ones == 4) { result = "fourteen"; }
            if (ones == 5) { result = "fifteen"; }
            if (ones == 6) { result = "sixteen"; }
            if (ones == 7) { result = "seventeen"; }
            if (ones == 8) { result = "eighteen"; }
            if (ones == 9) { result = "nineteen"; }

            return result;
        }

        static string Letterize(int n)
        {
            string result = "";
            if(n > 999) { return "too large"; }
            if (n < -999) { return "too small"; }
            if (n < 0) { result += "minus "; }
            n = Math.Abs(n);
            int hundreds = n / 100;
            if (hundreds == 1) { result+="one"; }
            if (hundreds == 2) { result += "two"; }
            if (hundreds == 3) { result += "three"; }
            if (hundreds == 4) { result += "four"; }
            if (hundreds == 5) { result += "five"; }
            if (hundreds == 6) { result += "six"; }
            if (hundreds == 7) { result += "seven"; }
            if (hundreds == 8) { result += "eight"; }
            if (hundreds == 9) { result += "nine"; }

            result += "-hundred";
            int ones = n % 10;
            int tens = (n / 10) % 10;
            if (ones != 0 || tens != 0)
            {
                result += " and ";
            }
            
            if (tens == 1) { result += teenIt(ones); return result; }
            if (tens == 2) { result += "twenty"; }else
            if (tens == 3) { result += "thirty"; }else
            if (tens == 4) { result += "fourty"; }else
            if (tens == 5) { result += "fifty"; }else
            if (tens == 6) { result += "sixty"; }else
            if (tens == 7) { result += "seventy"; }else
            if (tens == 8) { result += "eighty"; }else
            if (tens == 9) { result += "ninety"; }
            if (tens != 0)
            {
                result += " ";
            }
            if (ones == 1) { result += "one"; }else
            if (ones == 2) { result += "two"; }else
            if (ones == 3) { result += "three"; }else
            if (ones == 4) { result += "four"; }else
            if (ones == 5) { result += "five"; }else
            if (ones == 6) { result += "six"; }else
            if (ones == 7) { result += "seven"; }else
            if (ones == 8) { result += "eight"; }else
            if (ones == 9) { result += "nine"; }
            return result;
        }
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                int number = int.Parse(Console.ReadLine());
                if (number > 99 || number < -99)
                {
                    Console.WriteLine(Letterize(number));
                }
            }
        }
    }
}
