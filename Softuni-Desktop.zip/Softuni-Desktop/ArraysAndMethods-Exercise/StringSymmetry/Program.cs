﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringSymmetry
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] sentence = Console.ReadLine().Split(' ').ToArray();

            for (int i = 0; i < sentence.Length/2; i++)
            {
                if(sentence[i] != sentence[sentence.Length-(i+1)])
                {
                    Console.WriteLine("No");
                    return;
                }
            }
            Console.WriteLine("Yes");
        }
    }
}
