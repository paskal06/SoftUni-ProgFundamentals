﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CountOfCapLettets
{
    class Program
    {
        static void Main(string[] args)
        {
            int count = 0;
            string[] sentence = Console.ReadLine().Split(' ').ToArray();
            for (int i = 0; i < sentence.Length; i++)
            {
                if (sentence[i].Length == 1)
                {
                    string currentString = sentence[i];
                    char currentChar = currentString[0];
                    if(char.IsUpper(currentChar))
                    {
                        count++;
                    }
                }
            }
            Console.WriteLine(count);
        }
    }
}
