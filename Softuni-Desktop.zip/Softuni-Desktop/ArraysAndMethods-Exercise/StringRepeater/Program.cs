﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringRepeater
{
    class Program
    {
        static string RepeatString(string str, int count)
        {
            string repStr = string.Empty;
            for (int i = 1; i <= count; i++)
            {
                repStr = repStr + str;
                
            }
            return repStr;
        }
        static void Main(string[] args)
        {
            string String = Console.ReadLine();
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine(RepeatString(String, n));
            
        }
    }
}
