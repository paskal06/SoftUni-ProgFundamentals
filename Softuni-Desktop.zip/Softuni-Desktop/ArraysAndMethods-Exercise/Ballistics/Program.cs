﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ballistics
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] coordinates = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
            int planeX = coordinates[0];
            int planeY = coordinates[1];
            int CurrentX = 0;
            int CurrentY = 0;

            String[] commands = Console.ReadLine().Split(' ');

            for (int i = 0; i < commands.Length - 1; i += 2)
                
            {
                String position = commands[i];
                int offset = int.Parse(commands[i+1]);

                switch (position)
                {
                    case "right":
                        CurrentX += offset;
                        break;
                    case "left":
                        CurrentX -= offset;
                        break;
                    case "up":
                        CurrentY += offset;
                        break;
                    case "down":
                        CurrentY -= offset;
                        break;
                }
            }
            Console.WriteLine("firing at [{0}, {1}]",CurrentX,CurrentY);
            if(planeX == CurrentX && planeY == CurrentY)
            {
                Console.WriteLine("got 'em!");
            }else { Console.WriteLine("better luck next time..."); }
        }
        
    }
}
