﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CountOfOddNums
{
    class Program
    {
        static void Main(string[] args)
        {
            int count = 0;
            
            double[] numbers = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();
            double Element = double.Parse(Console.ReadLine());
            for (int i = 0; i < numbers.Length; i++)
            {
                if(numbers[i] > Element)
                {
                    count++;
                }
            }
            Console.WriteLine(count);
        }
    }
}
