﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NthDigit
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = int.Parse(Console.ReadLine());
            int position = int.Parse(Console.ReadLine());
            int lastNCounter = 0;
            for (int i = 0; i < position; i++)
            {
                lastNCounter = number % 10;
                number = number / 10;
            }

            if (number / position < 0)
            {
                Console.WriteLine("-");
            }
            else
            {
                Console.WriteLine(lastNCounter);
            }
        }
    }
}
