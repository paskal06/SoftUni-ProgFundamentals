﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MinMethod
{
    class Program
    {
        static int GetMin(int a, int b)
        {
            int c = 0;
            if (a > b)
            {
                c = b;
            }
            else
            {
                c = a;
            }
            return (c);
        }
        static void Main(string[] args)
        {
            int Min = 0;
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            Min = GetMin(a, b);
            int c = int.Parse(Console.ReadLine());
            Min = GetMin(Min, c);

            Console.WriteLine("{0}", Min);
        }
    }
}
