﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringEncryption
{
    class Program
    {
        static string Encrypt(char letter)
        {
            int code = Math.Abs(letter);
            int fd = code;
            int ld = code % 10;
            while (fd >= 10)
            {
                fd /= 10;
            }
            string result = string.Empty;
            char ldop = Convert.ToChar(letter + ld);
            char fdop = Convert.ToChar(letter - fd);
            result += ldop;
            result += fd;
            result += ld;
            result += fdop;
            return result;
        }

        static void Main(string[] args)
        {
            string result = string.Empty;
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                char letter = char.Parse(Console.ReadLine());

                result += Encrypt(letter);
            }
            Console.WriteLine(result);
        }
    }
}
