﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantDiscount
{
    class Program
    {
        static void Main(string[] args)
        {
            double SmallHall = 2500;
            double Terrace = 5000;
            double GreatHall = 7500;
            string loc = "";
            
            double Normal = 500;
            double Gold = 750;
            double Platinum = 1000;
            
            double sum = 0;

            int People = int.Parse(Console.ReadLine());
            string Package = Console.ReadLine();
            
            if (People <= 50)
            { sum = sum + SmallHall; loc = "Small Hall"; }
            else if (People > 50 && People <= 100)
            { sum = sum + Terrace; loc = "Terrace"; }
            else if (People > 100 && People <= 120)
            { sum = sum + GreatHall; loc = "Great Hall"; }
            else
            { Console.WriteLine("We do not have an appropriate hall."); return; }
            
            switch (Package)
            {
                case "Normal":
                    sum = sum + Normal;
                    sum = sum * 0.95;
                    break;
                case "Gold":
                    sum = sum + Gold;
                    sum = sum * 0.9;
                    break;
                case "Platinum":
                    sum = sum + Platinum;
                    sum = sum * 0.85;
                    break;
            }
            sum = sum / People;
            Console.WriteLine("We can offer you the {0}",loc);
            Console.WriteLine("The price per person is {0:0.00}$", sum);
        }
    }
}
