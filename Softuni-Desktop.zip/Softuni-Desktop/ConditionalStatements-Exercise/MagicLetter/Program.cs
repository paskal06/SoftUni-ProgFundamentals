﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MagicLetter
{
    class Program
    {
        static void Main(string[] args)
        {
            char firstLetter = char.Parse(Console.ReadLine().ToLower());
            char last = char.Parse(Console.ReadLine().ToLower());
            char ignoredLetter = char.Parse(Console.ReadLine().ToLower());
            for (char i = firstLetter; i <= last; i++)
            {
                for (char j = firstLetter; j <= last; j++)
                {
                    for (char k = firstLetter; k <= last; k++)
                    {
                        if (!i.Equals(ignoredLetter) && !j.Equals(ignoredLetter) && !k.Equals(ignoredLetter))
                        {
                            Console.Write($"{i}{j}{k}" + " ");
                        }
                    }
                }
            }

        }
    }
}
