﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int m = int.Parse(Console.ReadLine());
            int msb = int.Parse(Console.ReadLine());
            int totalsum = 0;
            int combinations = 0;
            
                for (int y = n; y >= 1; y--)
                {
                    for (int i = 1; i <= m; i++)
                    {
                    if (msb < totalsum) { break; }
                    else
                    {
                        totalsum = totalsum + (y * i) * 3;
                        combinations++;
                    }
                }
                
            }
            
            Console.WriteLine("{0} combinations", combinations);
            Console.Write("Sum: {0}", totalsum); if(totalsum >= msb) { Console.WriteLine(" >= {0}", msb); } else { Console.WriteLine(""); }
        }
    }
}
