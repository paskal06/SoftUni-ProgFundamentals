﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalloriesCounter
{
    class Program
    {
        static void Main(string[] args)
        {
            int Cheese = 500;
            int Tomato_Sauce = 150;
            int Salami = 600;
            int Pepper = 50;
            
            string ingredient = "None";
            int n = int.Parse(Console.ReadLine());
            int TotalCalories = 0;
            for (int i = 1; i <= n; i++)
            {
                ingredient = Console.ReadLine().ToLower();

                switch (ingredient)
                {
                    case "cheese":
                        TotalCalories = TotalCalories + Cheese;
                        break;
                    case "tomato sauce":
                        TotalCalories = TotalCalories + Tomato_Sauce;
                        break;
                    case "salami":
                        TotalCalories = TotalCalories + Salami;
                        break;
                    case "pepper":
                        TotalCalories = TotalCalories + Pepper;
                        break;
                }
            }
            Console.WriteLine("Total calories: {0}", TotalCalories);
        }
    }
}
