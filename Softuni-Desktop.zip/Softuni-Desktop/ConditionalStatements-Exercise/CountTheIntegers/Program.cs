﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CountTheIntegers
{
    class Program
    {
        static void Main(string[] args)
        {
            //int n = int.Parse(Console.ReadLine());
            int count = -1;
            while (true)
            {
                count++;
                
                try
                {
                    int n = int.Parse(Console.ReadLine());
                }
                catch (Exception)
                {
                    
                    Console.WriteLine(count);
                    return;
                }
            }
            
        }
    }
}
