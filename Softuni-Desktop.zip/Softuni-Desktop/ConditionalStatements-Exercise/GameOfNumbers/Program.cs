﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameOfNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            int matchCounter = 0;
            int counter = 0;
            int n = int.Parse(Console.ReadLine());
            int m = int.Parse(Console.ReadLine());
            int magicNum = int.Parse(Console.ReadLine());
            for (int i = m; i >= n; i--)
            {
                for (int j = m; j >= n; j--)
                {
                    sum = i + j;
                    counter++;
                    if (sum == magicNum)
                    {
                        Console.WriteLine("Number found! {0} + {1} = {2}", i, j, magicNum);
                        matchCounter++;
                        return;
                    }
                    
                }
            }
            if (matchCounter == 0)
            {
                Console.WriteLine("{0} combinations - neither equals {1}", counter, magicNum);
            }
        }
    }
}
