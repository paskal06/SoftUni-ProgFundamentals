﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConditionalStatements_Exercise
{
    class Program
    {
        static void Main(string[] args)
        {
            double Water = 0.70;
            double Coffee = 1.00;
            double Beer = 1.70;
            double Tea = 1.20;
            double sum = 0;

            //The Perfect Drink!!!
            string prof = Console.ReadLine();
            int quant = int.Parse(Console.ReadLine());
            switch (prof)
            {
                case "Athlete":
                    sum = quant * Water;
                    break;
                case "Businessman":
                case "Businesswoman":
                    sum = quant * Coffee;
                    break;
                case "SoftUni Student":
                    sum = quant * Beer;
                    break;
                default:
                    sum = quant * Tea;
                    break;
            }
            Console.WriteLine("The {0} has to pay {1:0.00}.", prof, sum);
        }
    }
}
