﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Baker
{
    class Program
    {
        static void Main(string[] args)
        {
            bool ok=false;
            int counter=0;
            while (ok == false)
            {
                string ingr = Console.ReadLine();
                if (ingr != "Bake!")
                {
                    Console.WriteLine("Adding ingredient {0}.", ingr);
                    counter++;
                }else
                {
                    Console.WriteLine("Preparing cake with {0} ingredients.", counter);
                    ok = true;
                }
            }
        }
    }
}
