﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hotel
{
    class Program
    {
        static void Main(string[] args)
        {
            double studio = 0;
            double doub = 0;
            double suite = 0;
            double free = 0;
            // Month Input and Modulators

            string Month = Console.ReadLine();
            int nc = int.Parse(Console.ReadLine());
            switch (Month)
            {
                case "May":
                case "October":
                    studio = 50;
                    doub = 65;
                    suite = 75;
                    
                    break;
                case "June":
                case "September":
                    studio = 60;
                    doub = 72;
                    suite = 82;
                    
                    break;
                case "July":
                case "August":
                case "December":
                    studio = 68;
                    doub = 77;
                    suite = 89;
                    
                    break;
            }
            //Discounts

            if (nc>7 && (Month == "May" || Month == "October"))
            {
                studio = studio * 0.95;
            }
            if (nc > 14 && (Month == "June" || Month == "September"))
            {
                doub = doub * 0.9;
            }
            if (nc > 14 && (Month == "July" || Month == "August" || Month == "December"))
            {
                suite = suite * 0.85;
            }
            if (nc > 7 && (Month == "September" || Month == "October"))
            {
                free = studio;
            }
            studio = studio * nc - free;
            doub = doub * nc;
            suite = suite * nc;

            Console.WriteLine("Studio: {0:0.00} lv.",studio);
            Console.WriteLine("Double: {0:0.00} lv.",doub);
            Console.WriteLine("Suite: {0:0.00} lv.",suite);
        }
    }
}
