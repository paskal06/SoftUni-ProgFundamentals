﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static bool Alive = true;
    static int LastOne;
    static int CurrentNum;
    static List<int> Nums = new List<int>();

    static void AddToList(int CurrentNum)
    {
        Nums.Insert(0, CurrentNum);
    }

    static void CheckEnd()
    {
        if (Nums.Count == 0)
        {
            Console.WriteLine("you shot them all. last one was {0}",LastOne);
        }
        else
        {
            Console.Write("survivors:");
            for (int i = 0; i < Nums.Count; i++)
            {
                Console.Write(" " + (Nums[i]));
            }
            Console.WriteLine();
        }
    }

    static void Bang()
    {
        
        if (Nums.Count == 0)
        {
            Console.WriteLine("nobody left to shoot! last one was {0}",LastOne);
            Alive = false;
            return;
        }
        double Average = Nums.Average();
        for (int i = 0; i < Nums.Count; i++)
        {
            if (Nums[i] <= Average)
            {
                
                    
                
                Console.WriteLine("shot {0}",Nums[i]);
                LastOne = Nums[i];
                for (int j = 0; j < Nums.Count; j++)
                    {
                        Nums[j]--;
                    }
                
                Nums.RemoveAt(i);
                return;
            }
        }
        

    }

    static void Main(string[] args)
    {



        //CommandCheck
        while (true)
        {
            if (Alive == false)
                {
                    return;
                }
            string Command = Console.ReadLine();
            if (Command == "stop")
            {
                CheckEnd();
                break;
            }
            if (Command == "bang")
            {
                
                Bang();
                
                continue;
            }
            CurrentNum = int.Parse(Command);
            AddToList(CurrentNum);
        }
    }
}

