﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecodeRadioFrequencies
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] Frequencies = Console
                            .ReadLine()
                            .Split(new Char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)
                            .Select(item => double.Parse(item))
                            .ToArray();
            
            List<int> Left = new List<int>();
            List<int> Right = new List<int>();
            for (int i = 0; i < Frequencies.Length; i++)
            {
                string s = Frequencies[i].ToString("000.000", CultureInfo.InvariantCulture);
                string[] parts = s.Split('.');
                int a = int.Parse(parts[0]);
                int b = int.Parse(parts[1]);
                if (b > 123) { b /= 10; }
                Left.Add(a);
                Right.Add(b);
                
            }
            Right.Reverse();
            for (int i = 0; i < Left.Count; i++)
            {
                if (Left[i] != 0)
                {
                    Console.Write("{0}", (char)Left[i]);
                    
                }

            }
            for (int i = 0; i < Right.Count; i++)
            {
                if (Right[i] != 0)
                {   
                    Console.Write("{0}",(char)Right[i]);
                    
                }
            }
            Console.WriteLine();
        }
    }
}
