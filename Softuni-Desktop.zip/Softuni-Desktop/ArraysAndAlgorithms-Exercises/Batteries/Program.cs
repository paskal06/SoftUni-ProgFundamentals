﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batteries
{
    class Program
    {
        static void Main(string[] args)
        {
            
            double[] Capacity = Console
                            .ReadLine()
                            .Split(new Char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)
                            .Select(item => double.Parse(item))
                            .ToArray();
            
            double[] UPH = Console
                            .ReadLine()
                            .Split(new Char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)
                            .Select(item => double.Parse(item))
                            .ToArray();

            int hours = int.Parse(Console.ReadLine());
            double hrs = hours;
            int[] lasted = new int[Capacity.Length];
            double[] HundredPercent = new double[Capacity.Length];
            double[] percentage = new double[Capacity.Length];
            for (int i = 0; i < HundredPercent.Length; i++)
            {
                HundredPercent[i] = Capacity[i];
            }

            while (hours > 0)
            {
                for (int i = 0; i < Capacity.Length; i++)
                {
                    
                    Capacity[i] -= UPH[i];
                    if (Capacity[i] < 0)
                    {
                        
                        continue;
                    }
                    lasted[i]++;

                }
                hours--;
            }
            
            for (int i = 0; i < Capacity.Length; i++)
            {
                if (Capacity[i] < 0) { Console.WriteLine("Battery {0}: dead (lasted {1} hours)",i+1,lasted[i]+1); } else {
                    percentage[i] = Capacity[i]/HundredPercent[i]*100 ;
                    Console.WriteLine("Battery {1}: {0:0.00} mAh ({2:0.00})%", Capacity[i], i+1, percentage[i]); }
            }
        }
    }
}
