﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayHistogram
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] Words = Console.ReadLine().Split(' ');
            string CurrentStr;
            double OnePercent = 1000000/Words.Length;
            for (int i = 0; i < Words.Length; i++)
            {
                var quant = Words.GroupBy(x => x)
                   .OrderByDescending(x => x.Count())
                   .Select(x => x.Key)
                   .ToList();
                try
                {
                    CurrentStr = quant[i];
                }catch(Exception e) { return; }
                int CurrentCount = 0;
                for (int j = 0; j < Words.Length; j++)
                {
                    if (Words[j] == CurrentStr)
                    {
                        CurrentCount++;

                    }
                }
                Console.WriteLine("{0} -> {1} times ({2:0.00}%)",CurrentStr,CurrentCount,(CurrentCount*OnePercent)/10000);
                
            }
        }
    }
}
