﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AverageCharDelimeter
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] Words = Console.ReadLine().Split(' ');
            char[] Letter;
            int sum = 0;
            int counter = 0;
            for (int i = 0; i < Words.Length; i++)
            {
                Letter = Words[i].ToCharArray();
                for (int j = 0; j < Letter.Length; j++)
                {
                    sum += (int)Letter[j];
                    counter++;
                }
            }
            int Average = sum / counter;
            if(Average >=97 && Average <= 122)
            {
                Average -= 32;
            }
            char result = (char)Average;
            for (int i = 0; i < Words.Length; i++)
            {
                Console.Write(Words[i]);
                if (i < Words.Length - 1)
                {
                    Console.Write(result);
                }
            }
            Console.WriteLine();
        }
    }
}
