﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortArray
{
    class Program
    {
        static void Main(string[] args)
        {
            //Tolkoz kod ne sum recikliral nikoga
            string[] Words = Console.ReadLine().Split(' ');
            string temp;
            bool swap;
            do
            {
                swap = false;
                for (int index = 0; index < (Words.Length - 1); index++)
                {
                    if (string.Compare(Words[index], Words[index + 1]) < 0)
                    {
                        //swap

                        temp = Words[index];
                        Words[index] = Words[index + 1];
                        Words[index + 1] = temp;
                        swap = true;
                    }
                }
            } while (swap == true);
            for (int i = 0; i < Words.Length / 2; i++)
            {
                temp = Words[i];
                Words[i] = Words[Words.Length - i - 1];
                Words[Words.Length - i - 1] = temp;
            }
            for (int i = 0; i < Words.Length; i++)
            {
                Console.Write(Words[i] + " ");
            }
            Console.WriteLine();
        }
    }
}
