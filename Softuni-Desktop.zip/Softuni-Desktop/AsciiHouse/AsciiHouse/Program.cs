﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsciiHouse
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Input Size (10 or above): ");
            int Size = int.Parse(Console.ReadLine());
            
            // Roof
            for (int i = 0; i < Size; i++)
            {
                Console.Write(new string(' ', Size-i));
                Console.Write("/");
                Console.Write(new string('#', i*2));
                Console.WriteLine("\\");
            }
            // Bottom 
            for (int i = 0; i < Size; i++)
            {
                Console.Write("|");
                Console.Write(new string(' ', (Size / 5)*2));
                if (i >= Size /4 && i < Size / 2)
                {
                    Console.Write(new string('+', (Size / 5)*2));
                }
                else { Console.Write(new string(' ', (Size / 5)*2)); }
                Console.Write(new string(' ', (Size / 5)*2));
                if (i >= Size / 4 && i < Size /2)
                {
                    Console.Write(new string('+', (Size / 5)*2));
                }
                else { Console.Write(new string(' ', (Size / 5)*2)); }
                Console.Write(new string(' ', (Size / 5) * 2));
                Console.WriteLine("|");
            }
            for (int i = 0; i < Size+1; i++)
            {
                Console.Write("&");
                Console.Write("$");
            }
        }
    }
}
