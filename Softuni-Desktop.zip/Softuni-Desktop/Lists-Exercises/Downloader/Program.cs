﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Downloader
{
    class Program
    {
        static void Main(string[] args)
        {
            var Blacklist = Console.ReadLine().Split(' ');
            
            string song = Console.ReadLine();

            var playlist = new List<string>();
            while(song != "end")
            {
                bool isContained = false;
                for (int i = 0; i < Blacklist.Length; i++)
                {
                    if (song.Contains(Blacklist[i]))
                    {
                        isContained = true;
                    }
                }

                if (!isContained)
                {
                    playlist.Add(song);
                }
                //playlist.Distinct();

                song = Console.ReadLine();
            }
            playlist.Sort();
            Console.WriteLine(string.Join("\r\n",playlist));
        }
    }
}
