﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TearListInHalf
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> list = Console.ReadLine().Split(' ').Select(int.Parse).ToList();
            

            List<int> firstLane = new List<int>();
            List<int> secondLane = new List<int>();

            for (int i = 0; i < list.Count/2; i++)
            {
                firstLane.Add(list[i]);
                //Console.WriteLine(firstLane[i]);
            }
            for (int i = 0; i < list.Count/2; i++)
            {
                secondLane.Add(list[i + list.Count / 2]);
                //Console.WriteLine(secondLane[i]);
            }

            List<int> Splits = new List<int>();

            for (int i = 0; i < list.Count/2; i++)
            {
                Splits.Add(secondLane[i] / 10);
                Splits.Add(secondLane[i] % 10);
                
            }
            List<int> Result = new List<int>();
            int j = 0;
            string space = " ";
            for (int i = 0; i < list.Count/2; i++)
            {
                if (i == list.Count / 2 - 1) { space = ""; }
                Console.Write(Splits[j] + " ");
                j++;
                Console.Write(firstLane[i]+" ");
                Console.Write(Splits[j] + space);
                j++;
            }
            Console.WriteLine();
        }
    }
}
