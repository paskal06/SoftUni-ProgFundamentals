﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SumExtraction
{
    class Program
    {
        static void Main(string[] args)
        {
            var firstSeq = Console.ReadLine().Split(' ').Select(int.Parse).ToList();
            var secondSeq = Console.ReadLine().Split(' ').Select(int.Parse).ToList();
            var filtered = new List<int>();
            for (int i = 0; i < firstSeq.Count; i++)
            {
                for (int j = 0; j < secondSeq.Count; j++)
                {
                    if (firstSeq[i] == secondSeq[j])
                    {
                        secondSeq.RemoveAt(j);
                        j--;
                    }
                }
            }
            //Zapomni .Sum()
            long firstSum = firstSeq.Sum();
            long secondSum = secondSeq.Sum();

            if(firstSum == secondSum)
            {
                Console.WriteLine("Yes. Sum: " + firstSum);
            }
            else
            {
                Console.WriteLine("No. Diff: " + Math.Abs(firstSum - secondSum));
            }
        }
    }
}
