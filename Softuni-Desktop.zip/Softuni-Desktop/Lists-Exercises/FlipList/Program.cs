﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlipList
{
    class Program
    {
        static void Main(string[] args)
        {
            var list = Console.ReadLine().Split(' ').Select(int.Parse).ToList();
            int temporary = 0;
            for (int i = 1; i < (list.Count)/2; i++)
            {
                temporary = list[i];
                list[i] = list[list.Count - i-1];
                list[list.Count - i-1] = temporary;
            }
            for (int i = 0; i < list.Count; i++)
            {
                Console.Write(list[i]+" ");
            }
        }
    }
}
