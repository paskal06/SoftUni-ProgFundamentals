﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lists_Exercises
{
    class Program
    {
        static void Main(string[] args)
        {

            var numbers = Console.ReadLine().Split(' ').ToList();

            for (int i = 1; i < numbers.Count; i+=2)
            {
                Console.Write(numbers[i]);
            }
            Console.WriteLine();
        }
    }
}
