﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam_Shopping
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            var Data = new Dictionary<string, int>();
            while (input != "shopping time")
            {
                List<string> Div = input.Split(' ').ToList();
                if (Div[0] == "stock")
                {
                    if (!Data.ContainsKey(Div[1]))
                    {
                        Data.Add(Div[1], int.Parse(Div[2]));
                    }
                    else
                    {
                        Data[Div[1]] += int.Parse(Div[2]);
                    }
                }
                input = Console.ReadLine();
            }
            while(input != "exam time")
            {
                List<string> Div = input.Split(' ').ToList();
                if (Div[0] == "buy")
                {
                    if (!Data.ContainsKey(Div[1]))
                    {
                        Console.WriteLine("{0} doesn't exist", Div[1]);
                        input = Console.ReadLine();
                        continue;
                    }
                    else if (Data[Div[1]] <= 0)
                    {
                        Console.WriteLine("{0} out of stock", Div[1]);
                        input = Console.ReadLine();
                        continue;
                    }
                    else
                    {
                        Data[Div[1]] -= int.Parse(Div[2]);
                    }

                }
                input = Console.ReadLine();
            }
            foreach (KeyValuePair<string, int> item in Data)
            {
                if(item.Value <= 0)
                {
                    continue;
                }
                Console.WriteLine($"{item.Key} -> {item.Value}");
            }
        }
    }
}
