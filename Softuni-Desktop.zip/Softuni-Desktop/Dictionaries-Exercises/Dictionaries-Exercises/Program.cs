﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dictionaries_Exercises
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            var Data = new SortedDictionary<string, long>();
            while (input != "Over")
            {
                List<string> Div = input.Split(' ').ToList();
                int num;
                if(int.TryParse(Div[0],out num))
                {
                    long temp = long.Parse(Div[0]);
                    Div[0] = Div[2];
                    Div[2] = temp.ToString();

                }
                
                Div[2] = long.Parse(Div[2]).ToString();
                Data.Add(Div[0], long.Parse(Div[2]));

                
                input = Console.ReadLine();
            }foreach (KeyValuePair<string, long> item in Data)
                {
                    Console.WriteLine($"{item.Key} -> {item.Value}");
                }
        }
    }
}
