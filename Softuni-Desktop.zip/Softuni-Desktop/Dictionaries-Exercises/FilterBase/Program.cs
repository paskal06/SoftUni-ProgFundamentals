﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        string input = Console.ReadLine();
        var age = new Dictionary<string, int>();
        var salary = new Dictionary<string, double>();
        var position = new Dictionary<string, string>();
        while(input!="filter base")
        {
            List<string> Div = input.Split(' ').ToList();
            int numi;
            double numd;

            if(int.TryParse(Div[2], out numi))
            {
                age.Add(Div[0], int.Parse(Div[2]));
            }else
            if (double.TryParse(Div[2], out numd))
            {
                salary.Add(Div[0], double.Parse(Div[2]));
            }
            else
            {
                position.Add(Div[0],Div[2]);
            }
            
            input = Console.ReadLine();
        }
        input = Console.ReadLine().ToLower();
        switch (input)
        {
            case "age":
                foreach (KeyValuePair<string, int> item in age)
                {
                    Console.WriteLine($"Name: {item.Key}");
                    Console.WriteLine($"Age: {item.Value}");
                    Console.WriteLine(new string('=', 20));
                }
                break;
            case "salary":
                foreach (KeyValuePair<string, double> item in salary)
                {
                    Console.WriteLine($"Name: {item.Key}");
                    Console.WriteLine("Salary: {0:0.00}", item.Value);
                    Console.WriteLine(new string('=', 20));
                }
                break;
            case "position":
                foreach (KeyValuePair<string, string> item in position)
                {
                    Console.WriteLine($"Name: {item.Key}");
                    Console.WriteLine($"Position: {item.Value}");
                    Console.WriteLine(new string('=', 20));
                }
                break;
        }
    }
}
