﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace asciiString
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string result = "";
            for (int i = 1; i <= n; i++)
            {
                int Code = int.Parse(Console.ReadLine());
                char str = (char)Code;
                result = result + str;
                
            }
            Console.WriteLine(result);
        }
    }
}
