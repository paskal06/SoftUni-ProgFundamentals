﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tricky_Strings
{
    class Program
    {
        static void Main(string[] args)
        {
            string all = "";
            string del = Console.ReadLine();
            int num = int.Parse(Console.ReadLine());
            for (int i = 1; i <= num; i++)
            {
                string adder = Console.ReadLine();
                all = all + adder;
                if (i != num)
                {
                    all = all + del;
                }
            }
            Console.WriteLine(all);
        }
    }
}
