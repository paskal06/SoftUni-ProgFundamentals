﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewShit
{
    class Program
    {
        static void Main(string[] args)
        {
            string SU = "Software University";
            char B = 'B';
            char y = 'y';
            char e = 'e';
            string ILP = "I love programming";
            Console.WriteLine(SU);
            Console.WriteLine(B);
            Console.WriteLine(y);
            Console.WriteLine(e);
            Console.WriteLine(ILP);
        }
    }
}
