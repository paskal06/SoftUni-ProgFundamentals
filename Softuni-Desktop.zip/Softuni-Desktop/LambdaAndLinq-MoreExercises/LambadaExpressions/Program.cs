﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LambadaExpressions
{
    class Program
    {
        static void Main(string[] args)
        {
            var Elements = new Dictionary<string,string>();
            var ElementsCount = new Dictionary<string, int>();
            string input = Console.ReadLine();
            while(input != "lambada")
            {
                if (input=="dance")
                {
                    //ElementsCount.Keys.ToList().ForEach(k => ElementsCount[k] = ElementsCount[k] + 1);
                    ElementsCount = ElementsCount.ToDictionary(p => p.Key, p => p.Value+1);
                    input = Console.ReadLine();
                    continue;
                }

                string[] inputTokens=input.Split(new string[] { " => " }, StringSplitOptions.None);
                string[] Data = inputTokens[1].Split('.');

                string Selector = inputTokens[0];
                string SelectorObject = Data[0];
                string property = Data[1];

                if (!Elements.ContainsKey(Selector))
                {
                    Elements.Add(Selector, property);
                    ElementsCount.Add(Selector, 1);
                }
                Elements[Selector] = property;
                

                input = Console.ReadLine();
            }

            foreach(var group in Elements)
            {
                Console.Write(group.Key + " => ");
                for (int i = 0; i < ElementsCount[group.Key]; i++)
                {
                    Console.Write("{0}.",group.Key);
                }
                Console.WriteLine(group.Value);
            }
            
        }
    }
}
