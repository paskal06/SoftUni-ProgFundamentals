﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArraysAndListAlgorithms_MoreExercises
{
    class Program
    {
        

        static void Main(string[] args)
        {
            List<string> str = Console.ReadLine().Split(' ').ToList();
            while (true)
            {
                string index = Console.ReadLine();

                if(index == "Print")
                {
                    break;
                }

                int x = int.Parse(index);

                List<string> Left = new List<string>();
                List<string> Right = new List<string>();

                for (int i = 0; i < x; i++)
                {
                    Left.Add(str[i]);
                }
                Left.Reverse();
                for (int i = x+1; i < str.Count; i++)
                {
                    Right.Add(str[i]);
                }
                Right.Reverse();
                Left.Add(str[x]);
                str = Left.Concat(Right).ToList();
            }
            for (int i = 0; i < str.Count; i++)
            {
                Console.Write("{0} ",str[i]);
            }
            Console.WriteLine();
        }
        
    }
}
