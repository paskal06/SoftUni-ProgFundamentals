﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extremums
{
    class Program
    {
        static void Main(string[] args)
        {
            string temp;
            string CommaSpace = ", ";
            List<int> Current = Console.ReadLine().Split(' ').Select(int.Parse).ToList();
            List<int> Result = new List<int>();
            string command = Console.ReadLine();
            for (int i = 0; i < Current.Count; i++)
            {
                int old = Current[i];
                List<int> calc = new List<int>();
                calc.Add(Current[i]);
                int CheckZero = Current[i].ToString().Length;
                for (int j = 0; j < Current[i].ToString().Length; j++)
                {
                    temp = old.ToString();
                    temp = ShiftString(temp);
                    old = int.Parse(temp);
                    calc.Add(old);
                }
                if(command == "Min")
                {
                    Result.Add(calc.Min());
                }
                if(command == "Max")
                {
                    Result.Add(calc.Max());
                }
            }
            for (int i = 0; i < Result.Count; i++)
            {
                if(i == Result.Count - 1) { CommaSpace = ""; }
                Console.Write(Result[i] + CommaSpace);
            }
            Console.WriteLine();
            Console.WriteLine(Result.Sum());
        }

        static string ShiftString(string t)
        {
            return t.Substring(1, t.Length - 1) + t.Substring(0, 1);
        }


    }
}
