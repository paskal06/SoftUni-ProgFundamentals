﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Japanese_Roulette
{
    class Program
    {
        static void Main(string[] args)
        {
            
            List<string> Cylinder = Console.ReadLine().Split(' ').ToList();
            List<string> Moves = Console.ReadLine().Split(' ').ToList();
            int i = 0;
            while (i < Moves.Count)
            {
                if (Cylinder[2]=="1")
                    {
                        Console.WriteLine("Game over! Player {0} is dead.",i);
                        return;
                    }
                Cylinder.Insert(0, Cylinder[Cylinder.Count-1]);
                
                Cylinder.RemoveAt(Cylinder.Count-1);
                Console.WriteLine(Cylinder[Cylinder.Count - 1]);

                List<string> CurrentMove = Moves[i].Split(',').ToList();
                for (int j = 0; j < int.Parse(CurrentMove[0]); j++)
                {
                    
                    if (CurrentMove[1] == "Left")
                    {
                        Cylinder.Add(Cylinder[0]);
                        Cylinder.RemoveAt(0);
                    }
                    if (CurrentMove[1] == "Right")
                    {
                        Cylinder.Insert(0, Cylinder[Cylinder.Count - 1]);
                        Cylinder.RemoveAt(Cylinder.Count - 1);
                    }
                    
                    
                    
                }
                
                i++;

            }
            Console.WriteLine("Everybody got lucky!");
        }
    }
}
