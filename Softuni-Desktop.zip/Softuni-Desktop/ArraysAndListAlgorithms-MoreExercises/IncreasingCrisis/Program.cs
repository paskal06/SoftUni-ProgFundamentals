﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());
        List<int> Nums = new List<int>();
        for (int i = 0; i < n; i++)
        {
            List<int> Current = Console.ReadLine().Split(' ').Select(int.Parse).ToList();

            for (int j = 0; j < Current.Count; j++)
            {
                if (Current[j] > Current[j + 1])
                {
                    Current.RemoveAt(j + 1);
                    
                    break;

                }
                if (Nums.Count == 0)
                {
                    for (int o = 0; o < Current.Count; o++)
                    {
                        Nums.Add(Current[o]);
                    }
                    break;
                }
                
            }


        }

        
        for (int i = 0; i < Nums.Count; i++)
        {
            Console.Write( Nums[i]+" ");
        }
        Console.WriteLine();
    }
}

