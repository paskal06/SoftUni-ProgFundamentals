﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KuciSolution
{
    class Program
    {
        static void Main(string[] args)
        {
            var size = int.Parse(Console.ReadLine());

            var dataInput = new HashSet<string>();
            var uniqueNames = new HashSet<string>();
            for (int i = 0; i < size; i++)
            {
                var input = Console.ReadLine();
                dataInput.Add(input);
                if (uniqueNames.Contains(input))
                { }
                else
                {
                    uniqueNames.Add(input);
                }
            }
            for (int i = 0; i < uniqueNames.Count; i++)
            {
                Console.WriteLine(uniqueNames.ElementAt(i));
            }
        }
    }
}
