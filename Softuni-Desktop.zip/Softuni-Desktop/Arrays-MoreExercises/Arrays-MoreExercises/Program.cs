﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays_MoreExercises
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] sentence = Console.ReadLine().Split(' ').ToArray();
            string current = "";
            for (int i = 0; i < sentence.Length; i++)
            {
                if(i>=2 && sentence[i] == sentence[i - 1] && sentence[i - 1] == sentence[i-2])
                {
                    current = sentence[i];
                }
            }
            Console.WriteLine(current+" " + current+" " + current);
        }
    }
}
