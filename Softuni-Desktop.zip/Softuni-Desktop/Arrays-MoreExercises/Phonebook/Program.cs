﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Phonebook
{
    class Program
    {
        
        static void Main(string[] args)
        {

            string[] Numbers = Console.ReadLine().Split(' ');

            string[] Names = Console.ReadLine().Split(' ');

            string[] results = new string[Names.Length];

            

            
            while (true)
            {
                string com = Console.ReadLine();
                if (com == "done")
                {
                    //results.ToList().ForEach(x => Console.WriteLine(x));
                    //for (int i = 0; i < resultAddress; i++)
                   // {
                    //    Console.WriteLine(results[i]);
                    //}

                    return;
                }

                for (int i = 0; i < Names.Length; i++)
                {

                    if (Names[i] == com)
                    {
                        Console.WriteLine(Names[i] + " -> " + Numbers[i]);

                        

                    }

                }


            }

        }
    }
}
