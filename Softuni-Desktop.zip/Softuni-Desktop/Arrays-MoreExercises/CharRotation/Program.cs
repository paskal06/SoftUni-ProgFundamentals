﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CharRotation
{
    class Program
    {
        static void Main(string[] args)
        {
            string Letter = Console.ReadLine();

            char[] Text = Letter.ToCharArray();
            
            int[] numbers = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

            for (int i = 0; i < numbers.Length; i++)
            {
                if(numbers[i] % 2 == 0)
                {
                    Text[i] -= (char)numbers[i];

                }
                else
                {
                    Text[i] += (char)numbers[i];
                }
                Console.Write(Text[i]);
                
            }
            Console.WriteLine("");

            
            
        }
    }
}
