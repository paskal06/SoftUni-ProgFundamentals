﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Phone
{
    class Program
    {
        static string[] Numbers;
        static string[] Names;
        static void Main(string[] args)
        {

            Numbers = Console.ReadLine().Split(' ');

            Names = Console.ReadLine().Split(' ');

            string[] inputTokens = Console.ReadLine().Split(' ');

            while(inputTokens[0] != "done")
            {
                string command = inputTokens[0];
                string argument = inputTokens[1];
                string entry = GetEntry(argument);
                string name;
                string number;
                string output;

                if (IsNumber(argument))
                {
                    name = entry;
                    number = argument;
                    output = name;
                }
                else
                {
                    name = argument;
                    number = entry;
                    output = number;
                }
                int digitSum = GetDigitSum(number);
                if (command == "call")
                {
                    //call
                    Console.WriteLine("calling {0}...",output);
                    if (digitSum % 2 == 1)
                    {
                        Console.WriteLine("no answer");
                    }
                    else
                    {
                        int minutes = digitSum / 60;
                        int seconds = digitSum % 60;
                        Console.WriteLine("call ended. duration: {0:00}:{1:00}", minutes, seconds);
                    }
                }
                else if (command == "message")
                {
                    //msg
                    Console.WriteLine("sending sms to {0}...",output);
                    if (digitSum % 2 == 1)
                    {
                        Console.WriteLine("busy");
                    }
                    else
                    {
                        Console.WriteLine("meet me there");
                    }
                }
                
                inputTokens = Console.ReadLine().Split(' ');
            }

        }

        static int GetDigitSum(string telephoneNumber)
        {
            int sum = 0;
            for (int cnt = 0; cnt < telephoneNumber.Length; cnt++)
            {
                if (IsDigit(telephoneNumber[cnt]))
                {
                    sum += telephoneNumber[cnt] - '0';
                }
            }
            return sum;
        }

        static string GetEntry(string input)
        {
            for (int cnt = 0; cnt < Numbers.Length; cnt++)
            {
                if (Names[cnt] == input)
                {
                    return Numbers[cnt];
                }
                else if (Numbers[cnt] == input)
                {
                    return Names[cnt];
                }
            }

            return string.Empty;
        }

        static bool IsNumber(string input)
        {
            for (int cnt = 0; cnt < input.Length; cnt++)
            {
                if (IsDigit(input[cnt]))
                {
                    return true;
                }
            }
            return false;
        }

        static bool IsDigit(char symbol)
        {
            return (symbol >= '0' && symbol <= '9');           
        }
    }
}
