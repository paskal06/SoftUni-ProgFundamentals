﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMSTyping
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            
            string output = "";
            for (int i = 0; i < n; i++)
            {
                int m = 3;
                string currentInput = Console.ReadLine();
                int CurrentDigit = 0;
                int Repetitions = 0;

                if (currentInput.Length > 0)
                {
                    CurrentDigit = currentInput[0] - '0';
                    
                }
                

                char characterToPrint = (char)(((CurrentDigit - 2) * m) + currentInput.Length-1);
                characterToPrint += 'a';
                Console.Write(characterToPrint);
            }
            Console.WriteLine();
        }
    }
}
