﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BPMcounter
{
    class Program
    {
        static void Main(string[] args)
        {
            int minutes = 0;
            double BPM = double.Parse(Console.ReadLine());
            double numberOfBeats = double.Parse(Console.ReadLine());

            double bars = numberOfBeats / 4;
            
            double seconds = 60 * numberOfBeats/BPM;
            
            while (seconds > 59)
            {
                seconds = seconds - 60;
                minutes++;
            }
            
            

            Console.WriteLine($"{Math.Round(bars,1)} bars - {minutes}m {Math.Floor(seconds)}s");
        }
    }
}
