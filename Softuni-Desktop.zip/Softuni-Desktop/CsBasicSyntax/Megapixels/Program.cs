﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Megapixels
{
    class Program
    {
        static void Main(string[] args)
        {
            double Width = double.Parse(Console.ReadLine());
            double Height = double.Parse(Console.ReadLine());

            double MegaPixels = (Width * Height) / 1000000;
            MegaPixels = Math.Round(MegaPixels,1);
            ;
            Console.WriteLine("{0}x{1} => {2}MP",Width,Height,MegaPixels);
        }
    }
}
