﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNAsequence
{
    class Program
    {
        static void Main(string[] args)
        {
            int MatchSum = int.Parse(Console.ReadLine());
            char seq = 'O';
            int line = 0;

            int Center = 1;
            int Left = 0;
            int Right = 1;

            char C = 'A';
            char L = 'A';
            char R = 'A';

            while (true)
            {
                if(line % 4 == 0 && line != 0)
                {
                    Console.WriteLine("");
                }
                Left++;
                if (Left > 4)
                {
                    Center++;
                    Left = 1;
                }
                if (Center > 4)
                {
                    Right++;
                    Center = 1;
                }
                if (Right > 4)
                {
                    return;
                }
                switch (Left)
                {
                    case 1:
                        L = 'A';
                        break;
                    case 2:
                        L = 'C';
                        break;
                    case 3:
                        L = 'G';
                        break;
                    case 4:
                        L = 'T';
                        break;
                }
                switch (Right)
                {
                    case 1:
                        R = 'A';
                        break;
                    case 2:
                        R = 'C';
                        break;
                    case 3:
                        R = 'G';
                        break;
                    case 4:
                        R = 'T';
                        break;
                }
                switch (Center)
                {
                    case 1:
                        C = 'A';
                        break;
                    case 2:
                        C = 'C';
                        break;
                    case 3:
                        C = 'G';
                        break;
                    case 4:
                        C = 'T';
                        break;
                }
                if (Left + Right + Center >= MatchSum) { seq = 'O'; } else { seq = 'X'; }
                Console.Write("{0}{1}{2}{3}{0} ", seq, R, C, L);
                line++;

            }
        }
    }
}
