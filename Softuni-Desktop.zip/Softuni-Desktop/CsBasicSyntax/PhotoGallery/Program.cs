﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhotoGallery
{
    class Program
    {
        static void Main(string[] args)
        {
            string orient = "square";
            string Format = "B";
            int PhotoNum = int.Parse(Console.ReadLine());

            int day = int.Parse(Console.ReadLine());
            int month = int.Parse(Console.ReadLine());
            int year = int.Parse(Console.ReadLine());

            int hours = int.Parse(Console.ReadLine());
            int minutes = int.Parse(Console.ReadLine());

            double size = double.Parse(Console.ReadLine());

            if (size > 1000000000)
            {
                size = (size / 1000000000);
                Format = "GB";
            }else
            if (size > 1000000)
            {
                size = size / 1000000;
                Format = "MB";
            }else
            if (size > 1000)
            {
                size = size / 1000;
                Format = "KB";
            }

            size = Math.Round(size, 1);

            double width = double.Parse(Console.ReadLine());
            double height = double.Parse(Console.ReadLine());

            if (width > height) { orient = "landscape"; }else
            if (width < height) { orient = "portrait"; }else { orient = "square"; }

            Console.WriteLine("Name: DSC_{0:0000}.jpg",PhotoNum);
            Console.WriteLine("Date Taken: {0:00}/{1:00}/{2:0000} {3:00}:{4:00}", day, month, year, hours, minutes);
            Console.WriteLine("Size: {0}{1}", size, Format);
            Console.WriteLine("Resolution: {0}x{1} ({2})",width,height,orient);


        }
    }
}
