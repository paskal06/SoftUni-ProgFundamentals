﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainingHallEqpt
{
    class Program
    {
        static void Main(string[] args)
        {
            double Budget = double.Parse(Console.ReadLine());
            double Price2Pay = 0;
            int itemsToBuy = int.Parse(Console.ReadLine());
            int count = 0;
            while (true)
            {
                if (count >= itemsToBuy)
                {
                    Console.WriteLine("Subtotal: ${0:0.00}", Price2Pay);
                    if(Budget < Price2Pay)
                    {
                        Console.WriteLine("Not enough. We need ${0:0.00} more.",(Price2Pay-Budget));
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Money left: ${0:0.00}", (Budget - Price2Pay));
                        break;
                    }
                }
                string s = "";
                string itemName = Console.ReadLine();
                double itemPrice = double.Parse(Console.ReadLine());
                int itemCount = int.Parse(Console.ReadLine());
                if (itemCount > 1) { s = "s"; }
                
                    Console.WriteLine("Adding {0} {1}{2} to cart.", itemCount, itemName, s);

                    Price2Pay = Price2Pay + itemPrice * itemCount;
                
                count++;

            }
            int baitCount = 0;
            while (baitCount<10)
            {
                string bait = Console.ReadLine();
                baitCount++;
            }
        }
    }
}
