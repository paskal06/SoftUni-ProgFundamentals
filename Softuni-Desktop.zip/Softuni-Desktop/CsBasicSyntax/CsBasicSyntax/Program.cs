﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsBasicSyntax
{
    class Program
    {
        static void Main(string[] args)
        {
            //Vapor Store
            double OutFall4 = 39.99;
            double CSOG = 15.99;
            double ZplinterZell = 19.99;
            double Honored2 = 59.99;
            double RoverWatch = 29.99;
            double RoverWatchOE = 39.99;
            double TotalSpent = 0;

            double balance = double.Parse(Console.ReadLine());
            
            while (true)
            {
                
                
                string Game = Console.ReadLine();
                switch (Game)
                {
                    case "RoverWatch Origins Edition":
                    case "OutFall 4":
                        if(OutFall4 > balance)
                        {
                            Console.WriteLine("Too Expensive");
                            break;
                        }
                        Console.WriteLine("Bought {0}", Game);
                        TotalSpent = TotalSpent + OutFall4;
                        balance = balance - OutFall4;
                        break;
                    case "CS: OG":
                        if (CSOG > balance)
                        {
                            Console.WriteLine("Too Expensive");
                            break;
                        }
                        Console.WriteLine("Bought {0}", Game);
                        TotalSpent = TotalSpent + CSOG;
                        balance = balance - CSOG;
                        break;
                    case "Zplinter Zell":
                        if (ZplinterZell > balance)
                        {
                            Console.WriteLine("Too Expensive");
                            break;
                        }
                        Console.WriteLine("Bought {0}", Game);
                        TotalSpent = TotalSpent + ZplinterZell;
                        balance = balance - ZplinterZell;
                        break;
                    case "Honored 2":
                        if (Honored2 > balance)
                        {
                            Console.WriteLine("Too Expensive");
                            break;
                        }
                        Console.WriteLine("Bought {0}", Game);
                        TotalSpent = TotalSpent + Honored2;
                        balance = balance - Honored2;
                        break;
                    case "RoverWatch":
                        if (RoverWatch > balance)
                        {
                            Console.WriteLine("Too Expensive");
                            break;
                        }
                        Console.WriteLine("Bought {0}", Game);
                        TotalSpent = TotalSpent + RoverWatch;
                        balance = balance - RoverWatch;
                        break;
                    case "Game Time":
                        if (balance <= 0)
                        {
                            Console.WriteLine("Out of money!");
                            return;
                        }
                        Console.WriteLine("Total spent: ${0:0.00}. Remaining: ${1:0.00}",TotalSpent,balance);
                        return;
                    default:
                        Console.WriteLine("Not Found");
                        break;
                }
            }
        }
    }
}
