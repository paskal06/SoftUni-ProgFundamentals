﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IncrementVariable
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int overflows = 0;
            while (true)
            {
                if (n > byte.MaxValue)
                {
                    n = n - 256;
                    overflows++;
                }
                else
                {
                    break;
                }
            }
            Console.WriteLine("{0}",n);
            if (overflows != 0) {
                Console.WriteLine("Overflowed {0} times", overflows); }
        }
    }
}
