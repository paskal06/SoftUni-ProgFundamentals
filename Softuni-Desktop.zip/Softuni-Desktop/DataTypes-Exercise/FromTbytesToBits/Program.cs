﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FromTbytesToBits
{
    class Program
    {
        static void Main(string[] args)
        {
            double TB = double.Parse(Console.ReadLine());
            uint Multipl = (1024 * 1024 * 8);
            uint adder = 1024 * 1024;
            Console.WriteLine("{0}", (TB * Multipl * adder));
        }
    }
}
