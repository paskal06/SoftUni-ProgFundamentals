﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataTypes_Exercise
{
    class Program
    {
        static void Main(string[] args)
        {
            

            Console.WriteLine(Math.PI+"3238");
            Console.WriteLine(1.60217657);
            Console.WriteLine("7.8184261974584555216535342341");
        }
    }
}
