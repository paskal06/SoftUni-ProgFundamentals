﻿using System;
class Program
{
    static void Main(string[] args)
    {
        string delimiter = Console.ReadLine();
        var numberOfStrings = int.Parse(Console.ReadLine());

        var result = string.Empty;
        var currentString = string.Empty;
        for (int i = 0; i < numberOfStrings; i++)
        {
            currentString = Console.ReadLine();
            if (i == numberOfStrings-1)
            {
                result += currentString;
                break;
            }
            result += currentString + delimiter;
            //currentString = Console.ReadLine();
            //result += currentString;
        }
        Console.WriteLine(result);
    }
}
