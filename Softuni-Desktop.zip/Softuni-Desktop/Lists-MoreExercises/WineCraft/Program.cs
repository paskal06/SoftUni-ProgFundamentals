﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WineCraft
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> grapes = Console.ReadLine().Split().Select(int.Parse).ToList();
            int n = int.Parse(Console.ReadLine());
            int grapesCount = grapes.Count;
            
            while (grapesCount>=n)
            {
                //Counting Rounds
                for (int Counter = 0; Counter < n; Counter++)
                {

                    var grapesSort = new int[grapes.Count];
                    for (int i = 0; i < grapes.Count; i++)
                    {

                        if (grapes[i] > grapes[i - 1] && grapes[i] > grapes[i + 1]&&i>0&&i<grapesCount-1)
                        {
                            grapesSort[i] = 1;
                            grapesSort[i + 1]--;
                            grapesSort[i - 1]--;
                            i++;
                        }
                    }


                    //Calculate Grapes
                    for (int i = 0; i < grapes.Count; i++)
                    {
                        if (grapesSort[i] == 0 && grapes[i] > 0)
                        {
                            grapes[i]++;
                        }
                        else if (grapesSort[i] == 1)
                        {
                            grapes[i]++;
                            if (grapes[i - 1] > 0)
                            {
                                grapes[i]++;
                                grapes[i - 1]--;
                            }
                            if (grapes[i + 1] > 0)
                            {
                                grapes[i]++;
                                grapes[i + 1]--;
                            }
                            i++;
                        }
                    }
                }
                grapesCount = grapes.Count;

                for (int i = 0; i < grapes.Count; i++)
                {
                    if (grapes[i] <= n)
                    {
                        grapes[i] = 0;
                        grapesCount--;
                    }
                } 
            }
            Console.WriteLine(string.Join(" ", grapes.Where(x => x > n)));
            
        }
    }
}
