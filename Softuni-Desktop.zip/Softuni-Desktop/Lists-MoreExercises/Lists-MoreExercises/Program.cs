﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lists_MoreExercises
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ununion Lists
            List<int> primalList = Console.ReadLine().Split().Select(int.Parse).ToList();
            int n = int.Parse(Console.ReadLine());

            List<int> NumsToRemove = new List<int>();
            List<int> NumsToAdd = new List<int>();

            for (int i = 0; i < n; i++)
            {
                
                List<int> CurrentSequence = Console.ReadLine().Split().Select(int.Parse).ToList();

                for (int j = 0; j < primalList.Count; j++)
                {
                    for (int k = 0; k < CurrentSequence.Count; k++)
                    {
                        if (primalList[j] == CurrentSequence[k])
                        {
                            NumsToRemove.Add(primalList[j]);
                        }
                        if (!primalList.Contains(CurrentSequence[k])&& !NumsToAdd.Contains(CurrentSequence[k]))
                        {
                            NumsToAdd.Add(CurrentSequence[k]);
                        }
                    }
                }
                //test
                //Console.WriteLine("Nums To Add:");for (int j = 0; j < NumsToAdd.Count; j++) { Console.Write(NumsToAdd[j]+" "); } Console.WriteLine();Console.WriteLine("Nums To Remove:");for (int j = 0; j < NumsToRemove.Count; j++) { Console.Write(NumsToRemove[j] + " "); } Console.WriteLine();
                for (int j = 0; j < NumsToAdd.Count; j++)
                {
                    primalList.Add(NumsToAdd[j]);
                }
                for (int j = 0; j < NumsToRemove.Count; j++)
                {
                    primalList.Remove(NumsToRemove[j]);
                }
                NumsToAdd.Clear();
                NumsToRemove.Clear();
            }
            primalList.Sort();
            for (int i = 0; i < primalList.Count; i++)
            {
                Console.Write(primalList[i] + " ");
            }
            Console.WriteLine();
        }
    }
}
