﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimalLists
{
    class Program
    {
        static void Main(string[] args)
        {
            var primalList = Console.ReadLine()
                .Split()
                .Select(int.Parse)
                .ToList();
            var numberOfLines = int.Parse(Console.ReadLine());

            for (int i = 0; i < numberOfLines; i++)
            {
                var sequenceList = Console.ReadLine()
                .Split()
                .Select(int.Parse)
                .ToList();


                foreach (var containElement in primalList.Intersect(sequenceList))
                {
                    primalList.Remove(containElement);
                }

                primalList.AddRange(sequenceList);

            }

            primalList.Sort();
            Console.WriteLine(string.Join(" ", primalList));
        }
    }
}
