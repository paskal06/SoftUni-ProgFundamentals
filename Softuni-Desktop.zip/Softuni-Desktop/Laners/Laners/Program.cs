﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laners
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int old = 1;

            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write("*");
                }
                Console.Write(">");
                for (int t = 1; t-old < n*2; t++)
                {
                    Console.Write("-");
                    old++;
                }



                Console.WriteLine("");

            }

        }
    }
}
