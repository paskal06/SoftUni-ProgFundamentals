﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeerPong
{
    class Program
    {
        static void Main(string[] args)
        {
            var Data = new Dictionary<string, Dictionary<string,int>>();
            
            string input = Console.ReadLine();
            while(input!="stop the game")
            {
                
                string[] inputTokens = input.Split('|');
                string name = inputTokens[0];
                string Team = inputTokens[1];
                int points = int.Parse(inputTokens[2]);
                if (!Data.ContainsKey(Team))
                {
                    Dictionary<string, int> calc = new Dictionary<string, int>();
                    calc[name] = points;
                    Data.Add(Team,calc);
                    calc.Clear();
                }

                input = Console.ReadLine();
            }
            int count = 0;
            foreach(var comp in Data.OrderByDescending(x => x.Value.Values.Sum()).ThenBy(x => x.Key.Length))
            {
                count++;
                Console.WriteLine("{0}. {1}; Players:",count,comp.Key);
                
            }
        }
    }
}
