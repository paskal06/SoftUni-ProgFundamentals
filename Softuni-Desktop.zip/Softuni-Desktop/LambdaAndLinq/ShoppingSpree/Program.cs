﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
            var products = new Dictionary<string, double>();
            double budget = double.Parse(Console.ReadLine());
            string input = Console.ReadLine();
            while (input != "end")
            {
                string[] inputToken = input.Split(' ').ToArray();
                if(!products.ContainsKey(inputToken[0]))
                {
                    products.Add(inputToken[0], double.Parse(inputToken[1]));
                    
                }
                else
                {
                if ((products[inputToken[0]]) > double.Parse(inputToken[1]))
                {
                    products[inputToken[0]] = double.Parse(inputToken[1]);
                
                    
                }

                
            }
            input = Console.ReadLine();
        }
        if (budget < products.Values.Sum())
        {
            Console.WriteLine("Need more money... Just buy banichka");
            return;
        }
            foreach(var result in products.OrderByDescending(x => x.Value).ThenBy(x => x.Key.Length))
        {
            Console.WriteLine("{0} costs {1:0.00}",result.Key,result.Value);
        }
    }
}
