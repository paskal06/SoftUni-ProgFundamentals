﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CottageScrapper
{
    class Program
    {
        static void Main(string[] args)
        {
            int Count = 0;
            string input = Console.ReadLine();
            var Trees = new Dictionary<string, List<double>>();
            var Used = new List<double>();
            var unUsed = new List<double>();
            while (input != "chop chop")
            {
                string[] inputTokens = input.Split(new string[] { " -> " }, StringSplitOptions.None);
                Count++;
                if (!Trees.ContainsKey(inputTokens[0]))
                {
                    Trees.Add(inputTokens[0], new List<double>());
                }
                Trees[inputTokens[0]].Add(double.Parse(inputTokens[1]));
                input = Console.ReadLine();
                
            }

            string NeededType = Console.ReadLine();
            double NeededHeight = double.Parse(Console.ReadLine());
            List<double> ppm = Trees.Values.SelectMany(x => x).ToList();
            
            foreach(var log in Trees)
            {
                
                if (log.Key == NeededType)
                {
                    for (int i = 0; i < log.Value.Count; i++)
                    {
                        if(log.Value[i] >= NeededHeight)
                        {
                            Used.Add(log.Value[i]);
                        }
                        else
                        {
                            unUsed.Add(log.Value[i]);
                        }
                    }
                }
                else
                {
                    unUsed.AddRange(log.Value);
                }
            }
            
            

            Console.WriteLine("Price per meter: ${0:0.00}", Math.Round(ppm.Sum()/Count,2));
            Console.WriteLine("Used logs price: ${0:0.00}", Math.Round((ppm.Sum()/Count),2)*Used.Sum());
            Console.WriteLine("Unused logs price: ${0:0.00}", (Math.Round(ppm.Sum() / Count,2) * unUsed.Sum())*0.25);
            Console.WriteLine("CottageScraper subtotal: ${0:0.00}", Math.Round(ppm.Sum() / Count,2) * Used.Sum() + (Math.Round(ppm.Sum() / Count,2) * unUsed.Sum()) * 0.25);
        }
    }
}
