﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace _8.SoftUni_Beer_Pong
    {
        class Program
        {
            static void Main(string[] args)
            {
                //4.    SoftUni Beer Pong
                //In SoftUni it is time for the annual beer pong tournament. Last year the competition was a total disaster, because nobody was in //“condition” to keep track of the scores. Now it is your job to write a program, which will keep track of the total results. The //competition’s rules are simple:
                //•   All contestants are divided into teams
                //•   Every team should have exactly 3 participants
                //•   After a team has a total of 3 participants, any further attempt to add a participant should be ignored.
                //•   If a team has less than 3 participants – it gets disqualified and should not be printed.
                //Until you receive the command “stop the game” you will receive lines of input in the following format:
                //“team|player|pointsMade”
                //The total score of the team is the sum of the points made from every player.
                //Print every team, which has enough players in the following format:
                //{teamPosition}. {teamName}; Players:
                //###{firstPlayerName}: {points}
                //###{secondPlayerName}: {points}
                //###{thirdPlayerName}: {points}
                //Order the teams by total points in descending order and order each team’s players by the amount of points made, again in descending order.

                var input = Console.ReadLine().Split('|').ToList();
                var storage = new Dictionary<string, Dictionary<string, int>>();
                var team = input[1];
                var player = input[0];
                var points = int.Parse(input[2]);

                while (input[0] != "stop")
                {
                    team = input[1];
                    player = input[0];
                    points = int.Parse(input[2]);

                    if (!storage.ContainsKey(team))
                    {
                        storage[team] = new Dictionary<string, int>();
                        storage[team][player] = points;
                    }

                    else
                    {
                        if (!storage[team].ContainsKey(player))
                        {
                            if (storage[team].Count < 3)
                            {
                                storage[team].Add(player, points);
                            }
                        }
                    }


                    input = Console.ReadLine().Split('|', ' ').ToList();
                }
                var filteredTeams = storage.Where(x => x.Value.Count == 3).OrderByDescending(x => x.Value.Sum(p => p.Value));
                int count = 0;
                int rang = 1;
                foreach (var kvp in filteredTeams)
                {
                    count++;
                    var teamName = kvp.Key;
                    Dictionary<string, int> playersData = kvp.Value;
                    var sortedPlayersData = playersData.OrderByDescending(playerPoints => playerPoints.Value);
                    Console.WriteLine($"{count}. {teamName}; Players:");
                    foreach (var playerPoints in sortedPlayersData)
                    {
                        Console.WriteLine($"###{playerPoints.Key}: {playerPoints.Value}");
                    }
                }


            }
        }
    }

    
