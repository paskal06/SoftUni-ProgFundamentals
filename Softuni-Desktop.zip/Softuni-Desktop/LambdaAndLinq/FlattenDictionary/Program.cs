﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlattenDictionary
{
    class Program
    {
        static void Main(string[] args)
        {
            var mainWords = new Dictionary<string, Dictionary<string,string>>();
            var flattenedData = new Dictionary<string,List<string>>();
            string input = Console.ReadLine();
            while (input != "end")
            {
                string[] inputTokens = input.Split(' ');
                if (inputTokens[0] == "flatten")
                {
                    string keyToFlatten = inputTokens[1];
                    foreach(var record in mainWords)
                    {
                        string key = record.Key;
                        var innerRecord = record.Value;
                        if(key == keyToFlatten)
                        {
                        foreach(var innerRec in innerRecord)
                            {
                            string flattenedValue = innerRec.Key + innerRec.Value;
                            if (!flattenedData.ContainsKey(key))
                                {
                                    flattenedData.Add(key, new List<string>());
                                }
                            flattenedData[key].Add(flattenedValue);
                            }
                        }
                    }
                    mainWords[keyToFlatten] = new Dictionary<string, string>();
                }
                else
                {
                    if (!mainWords.ContainsKey(inputTokens[0]))
                {
                    mainWords.Add(inputTokens[0], new Dictionary<string, string>());
                }
                mainWords[inputTokens[0]][inputTokens[1]] = inputTokens[2];
                
                }
                
            input = Console.ReadLine();
            }

            var orderedData = mainWords.OrderByDescending(kvp => kvp.Key.Length);

            foreach(var dis in orderedData)
            {
                Console.WriteLine(dis.Key);
                string key = dis.Key;
                Dictionary<string, string> innerRecord = dis.Value;
                int Count = 1;
                foreach(var inner in innerRecord.OrderBy(x=>x.Key.Length))
                {
                    Console.WriteLine("{2}. {0} - {1}",inner.Key,inner.Value,Count);
                    Count++;
                }
                if (flattenedData.ContainsKey(key))
                {
                    foreach (var flat in flattenedData[key])
                {
                    Console.WriteLine("{0}. {1}",Count,flat);
                    Count++;
                }
                }
                
            }
        }
    }
}

