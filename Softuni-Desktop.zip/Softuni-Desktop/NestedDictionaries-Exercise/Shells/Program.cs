﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shells
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            Dictionary<string, List<int>> shells = new Dictionary<string, List<int>>();
            List<int> Values = new List<int>();
            while(input != "aggregate")
            {
                string KeyShell = input.Split(' ')[0];
                int Value = int.Parse(input.Split(' ')[1]);
                Values.Add(Value);
                if (!shells.ContainsKey(KeyShell))
                {
                    shells.Add(KeyShell, Values);
                }
                else
                {
                    shells[KeyShell].Add(Value);
                }
                input = Console.ReadLine();
            }
            foreach(var shell in shells)
            {
                Console.Write("{0} -> ",shell.Key);
                Console.Write(string.Join(", ", shell.Value));
            }
        }
    }
}
