﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelCompany
{
    class Program
    {
        static void Main(string[] args)
        {
            bool readyMode = false;
            var citiesAndTransport = new Dictionary<string, Dictionary<string, int>>();
            var citiesAndTourists = new Dictionary<string, int>();
            while (true)
            {
                string intro = Console.ReadLine();
                if (intro == "travel time!")
                    break;
                if (intro == "ready")
                {
                    readyMode = true;
                    continue;
                }
                if (readyMode == false)
                {
                    string city = intro.Split(':')[0];
                    string[] transports = intro.Split(':')[1].Split(',');
                    for (int br = 0; br < transports.Length; br++)
                    {
                        string vehicle = transports[br].Split('-')[0];
                        int capacity = int.Parse(transports[br].Split('-')[1]);
                        if (!citiesAndTransport.ContainsKey(city))
                            citiesAndTransport.Add(city, new Dictionary<string, int>());

                        if (!citiesAndTransport[city].ContainsKey(vehicle))
                            citiesAndTransport[city].Add(vehicle, capacity);

                        citiesAndTransport[city][vehicle] = capacity;
                    }
                }
                else
                {
                    string city = intro.Split(' ')[0];
                    int tourists = int.Parse(intro.Split(' ')[1]);
                    citiesAndTourists[city] = tourists;
                }
            }
            int touristsInCity, sumOfAllPlaces;
            foreach (var city in citiesAndTourists.Keys)
            {
                touristsInCity = sumOfAllPlaces = 0;
                touristsInCity = citiesAndTourists[city];
                foreach (var item in citiesAndTransport[city])
                {
                    sumOfAllPlaces = sumOfAllPlaces + item.Value;
                }
                if (sumOfAllPlaces > touristsInCity)
                    Console.WriteLine($"{city} -> all {touristsInCity} accommodated");
                else if (sumOfAllPlaces <= touristsInCity)
                    Console.WriteLine($"{city} -> all except {touristsInCity - sumOfAllPlaces} accommodated");
            }
        }
    }
}
